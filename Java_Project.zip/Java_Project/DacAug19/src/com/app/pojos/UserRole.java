package com.app.pojos;

public enum UserRole {
ADMIN,STUDENT
}
