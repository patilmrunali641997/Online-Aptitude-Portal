package com.app.Dao;

import java.util.List;

import com.app.pojos.Subject;

public interface ISubject
{
    Subject addSubject(Subject subject);
    String deleteSubject(Subject subject);
    String updateSubject(Subject subject);
    List<Subject> listSubject();
}
